## 作业要求
* 1.编写Grunt或Gulp脚本对Sass或者Less进行编译。
* 2.符合性能优化标准进行压缩合并以及充分利用Less或Sass优势少写代码。